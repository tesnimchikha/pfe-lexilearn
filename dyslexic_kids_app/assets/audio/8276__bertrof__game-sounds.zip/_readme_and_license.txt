Pack downloaded from Freesound
----------------------------------------

"Game Sounds"

This Pack of sounds contains sounds by the following user:
 - Bertrof ( https://freesound.org/people/Bertrof/ )

You can find this pack online at: https://freesound.org/people/Bertrof/packs/8276/


Licenses in this Pack (see below for individual sound licenses)
---------------------------------------------------------------

Attribution 3.0: http://creativecommons.org/licenses/by/3.0/


Sounds in this Pack
-------------------

  * 131662__bertrof__game-sound-correct_v2.wav.wav
    * url: https://freesound.org/s/131662/
    * license: Attribution 3.0
  * 131660__bertrof__game-sound-correct.wav.wav
    * url: https://freesound.org/s/131660/
    * license: Attribution 3.0
  * 131659__bertrof__game-sound-intro-to-game.wav.wav
    * url: https://freesound.org/s/131659/
    * license: Attribution 3.0
  * 131658__bertrof__game-sound-selection.wav.wav
    * url: https://freesound.org/s/131658/
    * license: Attribution 3.0
  * 131657__bertrof__game-sound-wrong.wav.wav
    * url: https://freesound.org/s/131657/
    * license: Attribution 3.0


